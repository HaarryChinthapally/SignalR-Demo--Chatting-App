import {Component} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'slide-toggle-e2e',
  templateUrl: 'slide-toggle-e2e.html',
})
export class SlideToggleE2E { }
