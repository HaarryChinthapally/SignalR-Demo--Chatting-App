import {Component} from '@angular/core';


@Component({
  moduleId: module.id,
  selector: 'icon-e2e',
  templateUrl: 'icon-e2e.html',
})
export class IconE2E {}
