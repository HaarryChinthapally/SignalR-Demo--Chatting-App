import {Component} from '@angular/core';


@Component({
  moduleId: module.id,
  selector: 'list-e2e',
  templateUrl: 'list-e2e.html',
})
export class ListE2E {}
