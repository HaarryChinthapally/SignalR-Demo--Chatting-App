import {Component} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'checkbox-e2e',
  templateUrl: 'checkbox-e2e.html',
})
export class SimpleCheckboxes {}
