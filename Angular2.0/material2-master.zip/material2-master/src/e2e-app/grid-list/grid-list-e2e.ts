import {Component} from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'grid-list-e2e',
  templateUrl: 'grid-list-e2e.html',
})
export class GridListE2E {}
