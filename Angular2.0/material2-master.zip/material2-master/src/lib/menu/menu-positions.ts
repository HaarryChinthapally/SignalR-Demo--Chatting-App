
export type MenuPositionX = 'before' | 'after';

export type MenuPositionY = 'above' | 'below';
