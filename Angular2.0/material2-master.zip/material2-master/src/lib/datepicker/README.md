Please see the official documentation at https://material.angular.io/components/component/datepicker
