import {Component} from '@angular/core';


@Component({
  moduleId: module.id,
  selector: 'toolbar-demo',
  templateUrl: 'toolbar-demo.html',
  styleUrls: ['toolbar-demo.css'],
})
export class ToolbarDemo {

}
